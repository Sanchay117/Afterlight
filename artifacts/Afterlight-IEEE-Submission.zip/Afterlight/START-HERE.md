# AFTERLIGHT — IEEE ClimateChain submission

Live app: https://afterlight-3ch7.onrender.com/
Video: https://youtu.be/JrWJmzfMmjQ
Public source: https://github.com/Sanchay117/Afterlight
Track: Renewable Energy & Energy Trading — renewable certificate tracking.

## Try the demonstration
Open the live app and choose "Try to break it". Each visitor gets a separate temporary chain. Sessions expire after 20 idle minutes or service restart. If the free service is waking, allow about a minute.

## Run the source
Use Node.js 22 or newer in this folder:

    npm ci
    npm run build
    npm test
    npm start

Open http://127.0.0.1:4173. This local mode persists its chain in .data. No runtime API key or external wallet is required. See docs/DEPLOY.md for hosted mode.

## Included evidence and media
- artifacts/verification.json records the tested live origin and complete certificate workflow.
- artifacts/clean-evidence.json contains the exportable evidence packet.
- artifacts/afterlight-demo.mp4 is the 4:34 narrated film with original graphics and music.
- artifacts/devpost/ contains the 3:2 card, gallery and exact form fields.
- docs/DEVPOST-ABOUT.md is the seven-section project story.
- data/ contains the public PVGIS snapshot, model and provenance.
- contracts/ contains the Solidity source and matching compiled artifact.

PVGIS output is modeled; attack cases are controlled demonstrations. These are local-EVM demo certificates, not accredited renewable certificates. No avoided CO2 or real-meter fraud accuracy is claimed. The hosted blockchain has a temporary session lifetime.

The archive excludes API keys, installed dependencies, local ledger state and Git history. Source base commit: 9b5589eee78d3b110772378c486ee222154bbf06; this packet also includes the prepared submission text/assets. MANIFEST.sha256 records the exact included files.

The owner still completes the final Devpost submission. This packet is not a submission receipt.
